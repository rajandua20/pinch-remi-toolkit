# pinch-mcp — the first MCP server for Pinch Payments

22 tools (13 read · 9 confirm-guarded write). Security is the design:
no card or bank field exists in any tool schema, every write is confirm-guarded
in the tool layer (not the prompt), the public endpoint refuses `live`, and
refunds carry a non-overridable cap. See `README.md` and `SECURITY.md`.

## Run

```bash
npm install
cp .env.example .env          # add your Pinch SANDBOX keys
npm run build
node dist/index.js --http 3333 --cors     # or stdio for Claude Desktop
curl http://localhost:3333/healthz        # {"ok":true}
curl http://localhost:3333/meta           # toolCount: 22
```

Deploy to Cloud Run: see `DEPLOY.md`. No credentials are included in this
package — Pinch sandbox + synthetic customers only.
